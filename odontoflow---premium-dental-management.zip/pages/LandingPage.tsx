
import React from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronRight, 
  CheckCircle2, 
  Calendar, 
  Users, 
  FileText, 
  ShieldCheck, 
  Zap, 
  ArrowRight,
  Menu,
  X
} from 'lucide-react';
import Button from '../components/ui/Button';

const LandingPage: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  const navLinks = [
    { name: 'Funcionalidades', href: '#features' },
    { name: 'Benefícios', href: '#benefits' },
    { name: 'Preços', href: '#pricing' },
    { name: 'Depoimentos', href: '#testimonials' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md z-50 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-sky-600 rounded-lg flex items-center justify-center">
                <ShieldCheck className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-slate-900 tracking-tight">Odonto<span className="text-sky-600">Flow</span></span>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="text-slate-600 hover:text-sky-600 font-medium transition-colors"
                >
                  {link.name}
                </a>
              ))}
              <Button variant="outline" size="sm">Entrar</Button>
              <Button variant="primary" size="sm">Começar Agora</Button>
            </div>

            {/* Mobile Nav Button */}
            <div className="md:hidden">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-600 p-2"
              >
                {isMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="md:hidden bg-white border-b border-slate-100"
          >
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="block text-slate-600 font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-4 flex flex-col gap-3">
                <Button variant="outline" className="w-full">Entrar</Button>
                <Button variant="primary" className="w-full">Começar Agora</Button>
              </div>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="flex-1 text-center lg:text-left">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                variants={fadeIn}
              >
                <span className="inline-flex items-center px-4 py-1.5 rounded-full text-sm font-medium bg-sky-50 text-sky-700 mb-6">
                  ✨ Nova versão 2.0 disponível
                </span>
                <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-tight mb-6">
                  A gestão da sua clínica <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-emerald-600">
                    nunca foi tão simples.
                  </span>
                </h1>
                <p className="text-lg text-slate-600 mb-10 max-w-2xl mx-auto lg:mx-0">
                  O software completo para dentistas que buscam excelência. Agenda inteligente, prontuário digital e financeiro integrado em uma única plataforma premium.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                  <Button variant="primary" size="lg" className="w-full sm:w-auto">
                    Teste Grátis por 14 dias
                  </Button>
                  <Button variant="outline" size="lg" className="w-full sm:w-auto gap-2">
                    Ver demonstração <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
                <div className="mt-8 flex items-center justify-center lg:justify-start gap-4 text-slate-500 text-sm">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Sem cartão de crédito
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Suporte VIP 24/7
                  </div>
                </div>
              </motion.div>
            </div>
            <div className="flex-1 w-full relative">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative z-10"
              >
                <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 p-4 overflow-hidden">
                  <img 
                    src="https://picsum.photos/seed/dashboard/800/600" 
                    alt="Dashboard Preview" 
                    className="rounded-xl w-full"
                  />
                </div>
                {/* Decorative elements */}
                <div className="absolute -top-6 -right-6 w-32 h-32 bg-sky-100 rounded-full blur-3xl opacity-60 -z-10"></div>
                <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-emerald-100 rounded-full blur-3xl opacity-60 -z-10"></div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-12 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm font-semibold text-slate-400 uppercase tracking-widest mb-8">
            Utilizado por mais de 2.000 dentistas em todo o Brasil
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-20 opacity-40 grayscale">
            <div className="text-2xl font-bold">DENTALCREARE</div>
            <div className="text-2xl font-bold">SORRISOOK</div>
            <div className="text-2xl font-bold">CLINICODONTO</div>
            <div className="text-2xl font-bold">ODONTOVIP</div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-sky-600 font-semibold mb-2">Recursos</h2>
            <h3 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
              Tudo o que você precisa em um só lugar
            </h3>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Desenvolvemos as ferramentas mais modernas para automatizar sua rotina e focar no que importa: o sorriso do seu paciente.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                title: 'Agenda Inteligente', 
                desc: 'Organize consultas, envie lembretes via WhatsApp e reduza faltas em até 40%.',
                icon: <Calendar className="w-6 h-6" />
              },
              { 
                title: 'Prontuário Digital', 
                desc: 'Evolução clínica, odontograma interativo e histórico completo com um clique.',
                icon: <FileText className="w-6 h-6" />
              },
              { 
                title: 'Gestão Financeira', 
                desc: 'Fluxo de caixa, emissão de boletos, notas fiscais e controle de inadimplência.',
                icon: <Zap className="w-6 h-6" />
              },
              { 
                title: 'Marketing & CRM', 
                desc: 'Campanhas de fidelização e acompanhamento pós-tratamento automático.',
                icon: <Users className="w-6 h-6" />
              },
              { 
                title: 'Segurança Total', 
                desc: 'Seus dados protegidos com criptografia de ponta e conformidade com a LGPD.',
                icon: <ShieldCheck className="w-6 h-6" />
              },
              { 
                title: 'Teleodontologia', 
                desc: 'Realize consultas remotas integradas diretamente no prontuário do paciente.',
                icon: <ArrowRight className="w-6 h-6" />
              }
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -5 }}
                className="p-8 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md transition-all"
              >
                <div className="w-12 h-12 bg-sky-50 text-sky-600 rounded-xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h4>
                <p className="text-slate-600">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-sky-600 font-semibold mb-2">Planos</h2>
            <h3 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
              Investimento que cabe no seu bolso
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              { 
                name: 'Iniciante', 
                price: '99', 
                features: ['Agenda Digital', 'Prontuário Ilimitado', 'Suporte via Email'],
                popular: false
              },
              { 
                name: 'Profissional', 
                price: '199', 
                features: ['Tudo do Iniciante', 'Financeiro Completo', 'Lembretes WhatsApp', 'Suporte Prioritário'],
                popular: true
              },
              { 
                name: 'Clínica', 
                price: '349', 
                features: ['Tudo do Profissional', 'Múltiplos Usuários', 'Marketing Integrado', 'Consultoria VIP'],
                popular: false
              }
            ].map((plan, idx) => (
              <div 
                key={idx}
                className={`p-8 bg-white rounded-2xl border ${plan.popular ? 'border-sky-500 ring-4 ring-sky-50' : 'border-slate-100'} relative`}
              >
                {plan.popular && (
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-sky-600 text-white px-4 py-1 rounded-full text-xs font-bold uppercase">
                    Mais Popular
                  </span>
                )}
                <h4 className="text-lg font-bold text-slate-900 mb-2">{plan.name}</h4>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-bold text-slate-900">R${plan.price}</span>
                  <span className="text-slate-500">/mês</span>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-600 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button 
                  variant={plan.popular ? 'primary' : 'outline'} 
                  className="w-full"
                >
                  Começar agora
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-sky-500 rounded-lg flex items-center justify-center">
                  <ShieldCheck className="text-white w-5 h-5" />
                </div>
                <span className="text-xl font-bold tracking-tight">OdontoFlow</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                Transformando a gestão odontológica através de tecnologia e design de classe mundial.
              </p>
            </div>
            <div>
              <h5 className="font-bold mb-6">Produto</h5>
              <ul className="space-y-4 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Funcionalidades</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Preços</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Novidades</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold mb-6">Empresa</h5>
              <ul className="space-y-4 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Sobre nós</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contato</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Carreiras</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold mb-6">Newsletter</h5>
              <p className="text-slate-400 text-sm mb-4">Receba dicas de gestão e marketing para sua clínica.</p>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="Seu email" 
                  className="bg-slate-800 border-none rounded-lg px-4 py-2 text-sm w-full focus:ring-2 focus:ring-sky-500 outline-none" 
                />
                <Button variant="primary" size="sm">Ok</Button>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-xs">
            <p>&copy; 2024 OdontoFlow. Todos os direitos reservados.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-white transition-colors">Privacidade</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
